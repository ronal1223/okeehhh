# bomsms
Bom sms hehe , jangan di salahgunakan ya kak

how to use

pkg install git

git clone https://github.com/amir404/bomsms

cd bomsms

php sms.php
